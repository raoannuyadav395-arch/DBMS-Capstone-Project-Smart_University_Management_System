require("dotenv").config();

const express = require("express");
const mysql = require("mysql2/promise");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

const pool = mysql.createPool({
  host: process.env.DB_HOST || "localhost",
  user: process.env.DB_USER || "root",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "smart_university",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

async function query(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

/* Dashboard: follows the project problem statement:
   overall students, courses, average marks and attendance defaulters. */
app.get("/api/dashboard", async (req, res) => {
  try {
    const [students] = await pool.execute("SELECT COUNT(*) AS total FROM students");
    const [courses] = await pool.execute("SELECT COUNT(*) AS total FROM courses");
    const [average] = await pool.execute("SELECT ROUND(AVG(marks),2) AS average_marks FROM exam_results");
    const [defaulters] = await pool.execute(`
      SELECT COUNT(DISTINCT student_id) AS total
      FROM attendance
      WHERE classes_held > 0
        AND (classes_attended / classes_held) * 100 < 75
    `);

    res.json({
      totalStudents: students[0].total,
      totalCourses: courses[0].total,
      averageMarks: average[0].average_marks || 0,
      defaulters: defaulters[0].total
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Students + department */
app.get("/api/students", async (req, res) => {
  try {
    const rows = await query(`
      SELECT s.student_id, s.student_name, s.email, s.gender,
             s.date_of_birth, s.admission_year,
             d.department_name
      FROM students s
      JOIN departments d ON s.department_id = d.department_id
      ORDER BY s.student_id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Courses + faculty + department */
app.get("/api/courses", async (req, res) => {
  try {
    const rows = await query(`
      SELECT c.course_id, c.course_code, c.course_name, c.credits,
             d.department_name, f.faculty_name
      FROM courses c
      JOIN departments d ON c.department_id = d.department_id
      LEFT JOIN faculty f ON c.faculty_id = f.faculty_id
      ORDER BY c.course_id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Attendance and 75% defaulter status */
app.get("/api/attendance", async (req, res) => {
  try {
    const rows = await query(`
      SELECT a.attendance_id, s.student_id, s.student_name,
             c.course_code, c.course_name,
             a.semester, a.classes_held, a.classes_attended,
             ROUND((a.classes_attended / a.classes_held) * 100, 2) AS attendance_percentage,
             CASE
               WHEN (a.classes_attended / a.classes_held) * 100 < 75
               THEN 'Defaulter'
               ELSE 'Eligible'
             END AS status
      FROM attendance a
      JOIN students s ON a.student_id = s.student_id
      JOIN courses c ON a.course_id = c.course_id
      ORDER BY attendance_percentage ASC, s.student_id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Exam results */
app.get("/api/results", async (req, res) => {
  try {
    const rows = await query(`
      SELECT er.result_id, s.student_id, s.student_name,
             c.course_code, c.course_name,
             e.exam_type, e.exam_date,
             er.marks, er.grade
      FROM exam_results er
      JOIN students s ON er.student_id = s.student_id
      JOIN examinations e ON er.exam_id = e.exam_id
      JOIN courses c ON e.course_id = c.course_id
      ORDER BY s.student_id, c.course_id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Course performance: average/highest/lowest */
app.get("/api/course-performance", async (req, res) => {
  try {
    const rows = await query(`
      SELECT c.course_id, c.course_name,
             ROUND(AVG(er.marks),2) AS average_marks,
             MAX(er.marks) AS highest_marks,
             MIN(er.marks) AS lowest_marks,
             COUNT(er.result_id) AS students_appeared
      FROM courses c
      JOIN examinations e ON c.course_id = e.course_id
      JOIN exam_results er ON e.exam_id = er.exam_id
      GROUP BY c.course_id, c.course_name
      ORDER BY average_marks DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Semester/academic ranking using the same RANK() idea as the SQL project */
app.get("/api/rankings", async (req, res) => {
  try {
    const rows = await query(`
      SELECT student_id, student_name, average_marks, academic_rank
      FROM (
        SELECT s.student_id, s.student_name,
               ROUND(AVG(er.marks),2) AS average_marks,
               RANK() OVER (ORDER BY AVG(er.marks) DESC) AS academic_rank
        FROM students s
        JOIN exam_results er ON s.student_id = er.student_id
        GROUP BY s.student_id, s.student_name
      ) ranked
      ORDER BY academic_rank, student_id
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* CTE: progression/performance category */
app.get("/api/progression", async (req, res) => {
  try {
    const rows = await query(`
      WITH student_scores AS (
        SELECT s.student_id, s.student_name,
               ROUND(AVG(er.marks),2) AS average_marks
        FROM students s
        JOIN exam_results er ON s.student_id = er.student_id
        GROUP BY s.student_id, s.student_name
      )
      SELECT student_id, student_name, average_marks,
             CASE
               WHEN average_marks >= 85 THEN 'Excellent'
               WHEN average_marks >= 70 THEN 'Good'
               WHEN average_marks >= 60 THEN 'Average'
               ELSE 'Needs Improvement'
             END AS performance_category
      FROM student_scores
      ORDER BY average_marks DESC
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Toppers: top 3 */
app.get("/api/toppers", async (req, res) => {
  try {
    const rows = await query(`
      SELECT student_id, student_name, average_marks, academic_rank
      FROM (
        SELECT s.student_id, s.student_name,
               ROUND(AVG(er.marks),2) AS average_marks,
               RANK() OVER (ORDER BY AVG(er.marks) DESC) AS academic_rank
        FROM students s
        JOIN exam_results er ON s.student_id = er.student_id
        GROUP BY s.student_id, s.student_name
      ) ranked
      WHERE academic_rank <= 3
      ORDER BY academic_rank
    `);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Searchable student endpoint */
app.get("/api/students/search", async (req, res) => {
  try {
    const q = `%${req.query.q || ""}%`;
    const rows = await query(`
      SELECT s.student_id, s.student_name, s.email, d.department_name
      FROM students s
      JOIN departments d ON s.department_id = d.department_id
      WHERE s.student_name LIKE ?
         OR s.email LIKE ?
         OR d.department_name LIKE ?
      ORDER BY s.student_id
    `, [q, q, q]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

/* Health check */
app.get("/api/health", async (req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ connected: true, database: process.env.DB_NAME || "smart_university" });
  } catch (err) {
    res.status(500).json({ connected: false, error: err.message });
  }
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
  console.log(`Smart University running at http://localhost:${PORT}`);
});