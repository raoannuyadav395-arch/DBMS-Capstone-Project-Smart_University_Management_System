# Smart University Management and Academic Analytics System

## Stack
- MySQL 8+
- Node.js
- Express.js
- mysql2
- HTML/CSS/JavaScript

## 1. Create the database
Open MySQL Workbench and run the original project SQL file:
`Smart_University_Capstone.sql`

It creates:
- departments
- students
- faculty
- courses
- registrations
- attendance
- examinations
- exam_results
- academic views and indexes

## 2. Install Node.js
Install Node.js LTS if it is not already installed.

Check:
```bash
node -v
npm -v
```

## 3. Configure database
Copy `.env.example` to `.env`.

Example:
```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=smart_university
PORT=3000
```

Do NOT put your MySQL password in frontend JavaScript.

## 4. Install dependencies
From this project folder:
```bash
npm install
```

## 5. Start
```bash
npm start
```

Open:
http://localhost:3000

## Features mapped to the problem statement
- Student management
- Course/faculty/department data
- Attendance defaulters below 75%
- Toppers / Top 3
- Course average, highest and lowest marks
- Academic ranking using SQL RANK() window function
- Student progression using a SQL CTE
- Exam result display
- Search students
- MySQL-backed dashboard

## Important
The browser does NOT connect directly to MySQL.
Browser -> Express API -> MySQL

This protects database credentials and is the correct architecture for the capstone demo.