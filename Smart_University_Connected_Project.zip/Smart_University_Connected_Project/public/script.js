const $ = (id) => document.getElementById(id);

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[c]));
}

async function api(url) {
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "API request failed");
  return data;
}

function showError(err) {
  const box = $("error-box");
  box.textContent = "Database/API error: " + err.message;
  box.classList.remove("hidden");
  setTimeout(() => box.classList.add("hidden"), 7000);
}

async function loadDashboard() {
  const d = await api("/api/dashboard");
  $("total-students").textContent = d.totalStudents;
  $("total-courses").textContent = d.totalCourses;
  $("average-marks").textContent = d.averageMarks;
  $("total-defaulters").textContent = d.defaulters;
}

async function loadRankings() {
  const rows = await api("/api/rankings");
  $("ranking-table").innerHTML = rows.slice(0,3).map(r => `
    <tr><td><b>#${r.academic_rank}</b></td><td>${esc(r.student_name)}</td><td>${r.average_marks}</td></tr>
  `).join("");
}

async function loadCoursePerformance() {
  const rows = await api("/api/course-performance");
  const max = Math.max(...rows.map(x => Number(x.average_marks)), 100);
  $("course-bars").innerHTML = rows.map(r => `
    <div class="bar-row">
      <div class="bar-label"><span>${esc(r.course_name)}</span><b>${r.average_marks}</b></div>
      <div class="bar"><div class="fill" style="width:${Math.min(Number(r.average_marks)/max*100,100)}%"></div></div>
      <small>Highest: ${r.highest_marks} | Lowest: ${r.lowest_marks}</small>
    </div>
  `).join("");
}

async function loadStudents() {
  const rows = await api("/api/students");
  renderStudents(rows);
  $("student-search").oninput = async (e) => {
    const q = e.target.value.trim();
    const data = q ? await api("/api/students/search?q=" + encodeURIComponent(q)) : rows;
    renderStudents(data);
  };
}

function renderStudents(rows) {
  $("students-table").innerHTML = rows.map(s => `
    <tr><td>${s.student_id}</td><td><b>${esc(s.student_name)}</b></td>
    <td>${esc(s.email)}</td><td>${esc(s.department_name)}</td><td>${s.admission_year}</td></tr>
  `).join("");
}

async function loadCourses() {
  const rows = await api("/api/courses");
  $("courses-table").innerHTML = rows.map(c => `
    <tr><td>${esc(c.course_code)}</td><td>${esc(c.course_name)}</td>
    <td>${c.credits}</td><td>${esc(c.department_name)}</td><td>${esc(c.faculty_name || "Not assigned")}</td></tr>
  `).join("");
}

async function loadAttendance() {
  const rows = await api("/api/attendance");
  $("attendance-table").innerHTML = rows.map(a => {
    const bad = a.status === "Defaulter";
    return `<tr><td>${esc(a.student_name)}</td><td>${esc(a.course_code)}</td>
      <td>${a.classes_held}</td><td>${a.classes_attended}</td>
      <td><b>${a.attendance_percentage}%</b></td>
      <td><span class="badge ${bad ? "bad" : "good"}">${a.status}</span></td></tr>`;
  }).join("");
}

async function loadResults() {
  const rows = await api("/api/results");
  $("results-table").innerHTML = rows.map(r => `
    <tr><td>${esc(r.student_name)}</td><td>${esc(r.course_code)}</td>
    <td>${esc(r.exam_type)}</td><td>${r.exam_date}</td>
    <td><b>${r.marks}</b></td><td>${esc(r.grade)}</td></tr>
  `).join("");
}

async function loadProgression() {
  const rows = await api("/api/progression");
  $("progression-table").innerHTML = rows.map(r => {
    const cls = r.performance_category === "Needs Improvement" ? "bad" :
                r.performance_category === "Average" ? "warn" : "good";
    return `<tr><td>${esc(r.student_name)}</td><td>${r.average_marks}</td>
      <td><span class="badge ${cls}">${esc(r.performance_category)}</span></td></tr>`;
  }).join("");
}

async function checkConnection() {
  try {
    const d = await api("/api/health");
    $("status-dot").style.background = "#39b85a";
    $("db-status").textContent = "MySQL connected";
  } catch (err) {
    $("status-dot").style.background = "#d83a3a";
    $("db-status").textContent = "MySQL disconnected";
    showError(err);
  }
}

async function loadAll() {
  try {
    await Promise.all([
      loadDashboard(), loadRankings(), loadCoursePerformance(),
      loadStudents(), loadCourses(), loadAttendance(),
      loadResults(), loadProgression(), checkConnection()
    ]);
  } catch (err) {
    showError(err);
  }
}

document.querySelectorAll(".nav-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    $(btn.dataset.page).classList.add("active");
    $("page-title").textContent = btn.textContent;
  });
});

loadAll();