-- SMART UNIVERSITY MANAGEMENT AND ACADEMIC ANALYTICS SYSTEM
-- DBMS Capstone Project
-- SQL Dialect: MySQL 8+

CREATE DATABASE IF NOT EXISTS smart_university;
USE smart_university;

DROP VIEW IF EXISTS vw_semester_rankings;
DROP VIEW IF EXISTS vw_student_academic_summary;
DROP VIEW IF EXISTS vw_course_performance;

DROP TABLE IF EXISTS exam_results;
DROP TABLE IF EXISTS examinations;
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS registrations;
DROP TABLE IF EXISTS courses;
DROP TABLE IF EXISTS faculty;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS departments;

-- 1. MASTER TABLES

CREATE TABLE departments (
    department_id INT PRIMARY KEY,
    department_name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE students (
    student_id INT PRIMARY KEY,
    student_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    gender VARCHAR(10),
    date_of_birth DATE,
    department_id INT NOT NULL,
    admission_year YEAR NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

CREATE TABLE faculty (
    faculty_id INT PRIMARY KEY,
    faculty_name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    department_id INT NOT NULL,
    designation VARCHAR(80),
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

CREATE TABLE courses (
    course_id INT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL UNIQUE,
    course_name VARCHAR(100) NOT NULL,
    credits INT NOT NULL CHECK (credits BETWEEN 1 AND 6),
    department_id INT NOT NULL,
    faculty_id INT,
    FOREIGN KEY (department_id) REFERENCES departments(department_id),
    FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id)
);

CREATE TABLE registrations (
    registration_id INT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester INT NOT NULL CHECK (semester BETWEEN 1 AND 8),
    academic_year VARCHAR(9) NOT NULL,
    registration_date DATE NOT NULL,
    UNIQUE(student_id, course_id, semester, academic_year),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

CREATE TABLE attendance (
    attendance_id INT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    semester INT NOT NULL,
    classes_held INT NOT NULL CHECK (classes_held >= 0),
    classes_attended INT NOT NULL, CONSTRAINT chk_attendence_classes CHECK(classes_attended >= 0 AND classes_attended <= classes_held),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

CREATE TABLE examinations (
    exam_id INT PRIMARY KEY,
    course_id INT NOT NULL,
    semester INT NOT NULL,
    exam_type VARCHAR(30) NOT NULL,
    exam_date DATE NOT NULL,
    max_marks INT NOT NULL DEFAULT 100,
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

CREATE TABLE exam_results (
    result_id INT PRIMARY KEY,
    exam_id INT NOT NULL,
    student_id INT NOT NULL,
    marks DECIMAL(5,2) NOT NULL CHECK (marks BETWEEN 0 AND 100),
    grade VARCHAR(2),
    FOREIGN KEY (exam_id) REFERENCES examinations(exam_id),
    FOREIGN KEY (student_id) REFERENCES students(student_id),
    UNIQUE(exam_id, student_id)
);

-- 2. SAMPLE DATA

INSERT INTO departments VALUES
(1,'Computer Science and Engineering'),
(2,'Electronics and Communication'),
(3,'Mechanical Engineering');

INSERT INTO faculty VALUES
(101,'Dr. Neha Sharma','neha@university.edu',1,'Professor'),
(102,'Dr. Raj Mehta','raj@university.edu',1,'Associate Professor'),
(103,'Dr. Priya Singh','priya@university.edu',2,'Professor'),
(104,'Dr. Amit Kumar','amit@university.edu',3,'Assistant Professor');

INSERT INTO students VALUES
(1001,'Aarav','aarav@university.edu','M','2005-04-12',1,2024),
(1002,'Ananya','ananya@university.edu','F','2005-07-19',1,2024),
(1003,'Rohan','rohan@university.edu','M','2004-12-02',1,2024),
(1004,'Priya','priya.student@university.edu','F','2005-02-22',2,2024),
(1005,'Karan','karan@university.edu','M','2004-11-14',3,2024),
(1006,'Simran','simran@university.edu','F','2005-08-30',1,2024);

INSERT INTO courses VALUES
(201,'CS301','Database Management Systems',4,1,101),
(202,'CS302','Data Structures',4,1,102),
(203,'CS303','Operating Systems',4,1,101),
(204,'EC301','Digital Electronics',4,2,103),
(205,'ME301','Thermodynamics',4,3,104);

INSERT INTO registrations VALUES
(1,1001,201,3,'2025-26','2025-07-10'),
(2,1001,202,3,'2025-26','2025-07-10'),
(3,1001,203,3,'2025-26','2025-07-10'),
(4,1002,201,3,'2025-26','2025-07-10'),
(5,1002,202,3,'2025-26','2025-07-10'),
(6,1002,203,3,'2025-26','2025-07-10'),
(7,1003,201,3,'2025-26','2025-07-10'),
(8,1003,202,3,'2025-26','2025-07-10'),
(9,1003,203,3,'2025-26','2025-07-10'),
(10,1004,204,3,'2025-26','2025-07-10'),
(11,1005,205,3,'2025-26','2025-07-10'),
(12,1006,201,3,'2025-26','2025-07-10'),
(13,1006,202,3,'2025-26','2025-07-10'),
(14,1006,203,3,'2025-26','2025-07-10');

INSERT INTO attendance VALUES
(1,1001,201,3,40,36),(2,1001,202,3,40,34),(3,1001,203,3,40,35),
(4,1002,201,3,40,38),(5,1002,202,3,40,37),(6,1002,203,3,40,36),
(7,1003,201,3,40,30),(8,1003,202,3,40,29),(9,1003,203,3,40,31),
(10,1004,204,3,40,35),(11,1005,205,3,40,32),
(12,1006,201,3,40,25),(13,1006,202,3,40,24),(14,1006,203,3,40,27);

INSERT INTO examinations VALUES
(301,201,3,'End Semester','2025-12-10',100),
(302,202,3,'End Semester','2025-12-12',100),
(303,203,3,'End Semester','2025-12-15',100),
(304,204,3,'End Semester','2025-12-11',100),
(305,205,3,'End Semester','2025-12-13',100);

INSERT INTO exam_results VALUES
(1,301,1001,92,'A+'),(2,302,1001,88,'A+'),(3,303,1001,90,'A+'),
(4,301,1002,95,'A+'),(5,302,1002,94,'A+'),(6,303,1002,93,'A+'),
(7,301,1003,72,'B+'),(8,302,1003,78,'B+'),(9,303,1003,75,'B+'),
(10,304,1004,86,'A'),(11,305,1005,81,'A'),(12,301,1006,58,'C'),
(13,302,1006,62,'B'),(14,303,1006,55,'C');

-- 3. BASIC SQL / DDL-DML EXAMPLES

SELECT * FROM students;
SELECT * FROM courses;

UPDATE students
SET email = 'aarav.new@university.edu'
WHERE student_id = 1001;

-- 4. JOINS

SELECT s.student_id, s.student_name, d.department_name
FROM students s
INNER JOIN departments d ON s.department_id = d.department_id;

SELECT s.student_name, c.course_name, r.semester, r.academic_year
FROM students s
LEFT JOIN registrations r ON s.student_id = r.student_id
LEFT JOIN courses c ON r.course_id = c.course_id
ORDER BY s.student_id;

SELECT c.course_name, f.faculty_name
FROM courses c
LEFT JOIN faculty f ON c.faculty_id = f.faculty_id;

-- 5. TOPPERS / COURSE PERFORMANCE

SELECT c.course_name, MAX(er.marks) AS highest_marks
FROM exam_results er
JOIN examinations e ON er.exam_id = e.exam_id
JOIN courses c ON e.course_id = c.course_id
GROUP BY c.course_id, c.course_name;

SELECT c.course_name, ROUND(AVG(er.marks),2) AS average_marks
FROM exam_results er
JOIN examinations e ON er.exam_id = e.exam_id
JOIN courses c ON e.course_id = c.course_id
GROUP BY c.course_id, c.course_name
ORDER BY average_marks DESC;

-- Student-wise average and topper
SELECT s.student_id, s.student_name, ROUND(AVG(er.marks),2) AS average_marks
FROM students s
JOIN exam_results er ON s.student_id = er.student_id
GROUP BY s.student_id, s.student_name
ORDER BY average_marks DESC;

-- 6. ATTENDANCE DEFAULTERS (<75%)

SELECT s.student_id, s.student_name, c.course_name,
       ROUND((a.classes_attended / a.classes_held) * 100,2) AS attendance_percentage
FROM attendance a
JOIN students s ON a.student_id = s.student_id
JOIN courses c ON a.course_id = c.course_id
WHERE (a.classes_attended / a.classes_held) * 100 < 75
ORDER BY attendance_percentage;

-- 7. VIEW: STUDENT ACADEMIC SUMMARY

CREATE VIEW vw_student_academic_summary AS
SELECT s.student_id, s.student_name, d.department_name,
       ROUND(AVG(er.marks),2) AS average_marks,
       COUNT(er.result_id) AS exams_attempted
FROM students s
JOIN departments d ON s.department_id = d.department_id
LEFT JOIN exam_results er ON s.student_id = er.student_id
GROUP BY s.student_id, s.student_name, d.department_name;

SELECT * FROM vw_student_academic_summary
ORDER BY average_marks DESC;

-- 8. VIEW: COURSE PERFORMANCE

CREATE VIEW vw_course_performance AS
SELECT c.course_id, c.course_name,
       ROUND(AVG(er.marks),2) AS average_marks,
       MAX(er.marks) AS highest_marks,
       MIN(er.marks) AS lowest_marks,
       COUNT(er.result_id) AS students_appeared
FROM courses c
JOIN examinations e ON c.course_id = e.course_id
JOIN exam_results er ON e.exam_id = er.exam_id
GROUP BY c.course_id, c.course_name;

SELECT * FROM vw_course_performance;

-- 9. WINDOW FUNCTION: SEMESTER-WISE RANKING

CREATE VIEW vw_semester_rankings AS
SELECT s.student_id, s.student_name,
       ROUND(AVG(er.marks),2) AS average_marks,
       RANK() OVER (ORDER BY AVG(er.marks) DESC) AS academic_rank
FROM students s
JOIN exam_results er ON s.student_id = er.student_id
GROUP BY s.student_id, s.student_name;

SELECT * FROM vw_semester_rankings
ORDER BY academic_rank;

-- 10. CTE: STUDENT PROGRESSION ANALYSIS

 WITH student_scores AS (
    SELECT s.student_id, s.student_name,
           ROUND(AVG(er.marks),2) AS average_marks
    FROM students s
    JOIN exam_results er ON s.student_id = er.student_id
    GROUP BY s.student_id, s.student_name
)
SELECT student_id, student_name, average_marks,
       CASE
           WHEN average_marks >= 85 THEN 'Excellent'
           WHEN average_marks >= 70 THEN 'Good'
           WHEN average_marks >= 60 THEN 'Average'
           ELSE 'Needs Improvement'
       END AS performance_category
FROM student_scores
ORDER BY average_marks DESC;

-- 11. SUBQUERY: ABOVE-AVERAGE STUDENTS

SELECT student_id, student_name
FROM students
WHERE student_id IN (
    SELECT er.student_id
    FROM exam_results er
    GROUP BY er.student_id
    HAVING AVG(er.marks) > (SELECT AVG(marks) FROM exam_results)
);

-- 12. CORRELATED SUBQUERY: STUDENTS ABOVE THEIR COURSE AVERAGE

SELECT s.student_name, c.course_name, er.marks
FROM exam_results er
JOIN students s ON er.student_id = s.student_id
JOIN examinations e ON er.exam_id = e.exam_id
JOIN courses c ON e.course_id = c.course_id
WHERE er.marks > (
    SELECT AVG(er2.marks)
    FROM exam_results er2
    JOIN examinations e2 ON er2.exam_id = e2.exam_id
    WHERE e2.course_id = e.course_id
);

-- 13. SET OPERATIONS
-- MySQL does not support INTERSECT/MINUS in older versions; UNION is shown here.
SELECT student_id FROM registrations WHERE course_id = 201
UNION
SELECT student_id FROM registrations WHERE course_id = 202;

-- 14. INDEXING

CREATE INDEX idx_student_department ON students(department_id);
CREATE INDEX idx_registration_student ON registrations(student_id);
CREATE INDEX idx_result_student ON exam_results(student_id);
CREATE INDEX idx_result_exam ON exam_results(exam_id);

-- Check indexes
SHOW INDEX FROM students;
SHOW INDEX FROM exam_results;

-- 15. USEFUL ANALYTICS

-- Number of students in each department
SELECT d.department_name, COUNT(s.student_id) AS total_students
FROM departments d
LEFT JOIN students s ON d.department_id = s.department_id
GROUP BY d.department_id, d.department_name;

-- Courses with average marks below 70
SELECT * FROM vw_course_performance
WHERE average_marks < 70;

-- Students with attendance below 75% in any course
SELECT DISTINCT s.student_id, s.student_name
FROM students s
JOIN attendance a ON s.student_id = a.student_id
WHERE a.classes_attended / a.classes_held < 0.75;

-- Top 3 students
SELECT *
FROM vw_semester_rankings
WHERE academic_rank <= 3
ORDER BY academic_rank;

-- 16. TRANSACTION CONTROL (TCL)

START TRANSACTION;
UPDATE students
SET email = 'temporary@university.edu'
WHERE student_id = 1003;
ROLLBACK;

-- Example COMMIT:
START TRANSACTION;
UPDATE students
SET email = 'rohan.updated@university.edu'
WHERE student_id = 1003;
COMMIT;

SHOW TABLES;

